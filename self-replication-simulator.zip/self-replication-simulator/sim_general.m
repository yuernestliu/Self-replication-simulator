clear
addpath(genpath([pwd '/subfunctions/']), '-begin')
WhichPart = 0; % ------ Initialise ------
SpecificSys

% ====================================================
% =================== Pre-setting ====================
ss = RandStream('mt19937ar','Seed', ssRandomSeed);
RandStream.setGlobalStream(ss)
R = 8.3144598;
NA = 6.022140857e23;
hPlanck = 6.626070040e-34;

P0 = 100000; % 100 kPa
T = 298.15;
THA = 1e3;
alpha = P0/NA/hPlanck; % Unit:  mol .m^-3 .s^-1
RT = R * T;
beta = RT / NA / hPlanck; % Unit:  s^-1

mEanum = NaN(fix(MaxL/2), MaxL);
for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        mEanum(i, j) = BigBarrierE; % in KJ/mol
        if i+j == MaxL
            mEanum(i, j) = Inf; % ------ solvent ------
        end
    end
end
n = zeros(1, MaxL);
rxn = Ini_rxn(MaxL);

WhichPart = 1; % ------ specify system ------
SpecificSys

[YesNo, nReac, nProd, eqReacProd] ...
    = IsOrNotSelfRep(rxn, MaxL);
[M1FoodMain, M2FoodSupp, M3ExcrPure, M4ForcSing, ...
    M5ForcMult, M6Relevant, NForcMult] = ClassifySet(nReac, nProd);
for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        if rxn(i, j) ~= 0
            mEanum(i, j) = LitBarrierE;
        end
    end
end
mEa = mEanum * THA;
% ------ Automatic Gnum ------
v = 1;
Disp_rxn(1, 6) = 1;
Gnum = NaN(1, MaxL);
tic
while v <= TRY
    if any(Disp_rxn(:, 6) >= 0)
        Gnum = Range( randi(length(Range), 1, MaxL) );
        Gnum(MaxL) = inf; % ------ solvent ------
        WhichPart = 12; % ------ manuall set G ------
        SpecificSys
        G = Gnum * THA;
        [rxnsInfo, Numrxns] = ...
            GetrxnsInfoANDOthers(G, mEa, MaxL, beta, RT);
        Disp_rxn = DispRxn(rxnsInfo, rxn, Numrxns, MaxL, THA);
    else
        break
    end
    v = v + 1;
end
toc
if v == TRY + 1
    disp('Stopped: Not Enough TRY')
    load train.mat;
    soundsc(y);
    return
end


recordT = 0;
recorddt = NaN;
recordN = n;
recordrate = 0;
recordInflowSum = zeros(1, MaxL);
InflowSum = zeros(1, MaxL);
sumn = sum(n);
rate = zeros(1, 1);
nOccur = NaN(MaxL, MaxL, 2);
h = 0;
for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        h = h + 1;
        rate(h) = rxnsInfo(h, 6) * n(i)/sumn * n(j)/sumn * sumn;
        nOccur(i, j, 1) = 0;
        h = h + 1;
        rate(h) = rxnsInfo(h, 6) * n(i+j)/sumn * sumn;
        nOccur(i, j, 2) = 0;
    end
end


% =======================================================
% ====================== Main ===========================
if CalcuKinetics
    
t = 0;
tn = 0;
ndt = 0;
tncount = 1;
WhichPart = 2;% ------ set stop condition ------
SpecificSys
while bool
    % ------ random decide dt ------
    sumrate = sum(rate);
    dt = exprnd( 1/sumrate );
    t = t + dt;
    ndt = ndt + 1;
    
    % ------ random choose one reaction ------
    NORMrate = rate / sumrate;
    rxnNum = find( cumsum(NORMrate) - rand >= 0, 1);

    if ~ ( rxnsInfo(rxnNum, 1) == rxnsInfo(rxnNum, 2) && ...
            n(rxnsInfo(rxnNum, 1)) == 1)

        ndt = 0;
        % ------ implement the chosen reaction ------
        if rxnsInfo(rxnNum, 4) == 1
            A = rxnsInfo(rxnNum, 1);
            B = rxnsInfo(rxnNum, 2);
            C = rxnsInfo(rxnNum, 3);
            n(A) = n(A) - 1;
            n(B) = n(B) - 1;
            n(C) = n(C) + 1;
            sumn = sumn - 1;
            if IsInfFlow
                [n, sumn, InflowSum] = InfSupply(n, A, B, C, sumn, ...
                    InflowSum, sfoodBag, 1);
            end
            rate = Updata_rate(rxnsInfo, n, rate, A, B, C, sumn);
            nOccur(A, B, 1) = nOccur(A, B, 1) + 1;
        else
            A = rxnsInfo(rxnNum, 1);
            B = rxnsInfo(rxnNum, 2);
            C = rxnsInfo(rxnNum, 3);
            n(A) = n(A) + 1;
            n(B) = n(B) + 1;
            n(C) = n(C) - 1;
            sumn = sumn + 1;
            if IsInfFlow
                [n, sumn, InflowSum] = InfSupply(n, A, B, C, sumn, ...
                    InflowSum, sfoodBag, 0);
            end
            rate = Updata_rate(rxnsInfo, n, rate, A, B, C, sumn);
            nOccur(A, B, 2) = nOccur(A, B, 2) + 1;
        end


        % ------ record ------
        tn = tn + 1;
        if mod(tn, DtnRecord) == 0
            tncount = tncount + 1;
            recordT(tncount) = t;
            recorddt(tncount) = dt;
            recordN(tncount, :) = n;
            recordInflowSum(tncount, :) = InflowSum;
            WhichPart = 3; % ------ record ------
            SpecificSys
        end
    end
    WhichPart = 2;
    SpecificSys
end
% ====================== Main ===========================
% =======================================================
toc
WhichPart = 4; % ------ draw outcomes ------
SpecificSys
end