function rxn = Ini_rxn(MaxL)

rxn = NaN(fix(MaxL/2), MaxL);
for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        rxn(i, j) = 0;
    end
end