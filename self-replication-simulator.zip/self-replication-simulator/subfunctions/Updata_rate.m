function rate = Updata_rate(rxns, n, rate, A, B, C, sumn)
for i = 1 : 2 : size(rxns, 1)
    temp1 = rxns(i, 1);
    temp2 = rxns(i, 2);
    if temp1 == A || temp1 == B || temp1 == C || ...
            temp2 == A || temp2 == B || temp2 == C
%         rate(i) = rxns(i, 6) * n(temp1)/sumn * n(temp2)/sumn;
        rate(i) = rxns(i, 6) * n(temp1)/sumn * n(temp2);
    end
    
    temp = rxns(i+1, 3);
    if temp == A || temp == B || temp == C
%         rate(i+1) = rxns(i+1, 6) * n(temp)/sumn;
        rate(i+1) = rxns(i+1, 6) * n(temp);
    end
end