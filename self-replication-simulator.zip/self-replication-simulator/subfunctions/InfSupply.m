function [n, sumn, InflowSum] = InfSupply(...
    n, A, B, C, sumn, InflowSum, sfoodBag, IsSyn)
if IsSyn
    if sum(A == sfoodBag)
        n(A) = n(A) + 1;
        sumn = sumn + 1;
        InflowSum(A) = InflowSum(A) + 1;
    end
    if sum(B == sfoodBag)
        n(B) = n(B) + 1;
        sumn = sumn + 1;
        InflowSum(B) = InflowSum(B) + 1;
    end
else
    if sum(C == sfoodBag)
        n(C) = n(C) + 1;
        sumn = sumn + 1;
        InflowSum(C) = InflowSum(C) + 1;
    end
end