function Disp_rxn = DispRxn(rxnsInfo, rxn, v, MaxL, THA)

Disp_rxn = NaN(1, 6);

k = 0;
for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        if rxn(i, j) ~= 0
            
            for b = 1 : v
                if rxnsInfo(b, 1) == i && rxnsInfo(b, 2) == j
                    k = k + 1;
                    if rxn(i, j) == 1
                        Disp_rxn(k, :) = [i  j  i+j  NaN ...
                            rxnsInfo(b, 5)/THA  ...
                            rxnsInfo(b, 5)/THA - rxnsInfo(b+1, 5)/THA];
                    else
                        Disp_rxn(k, :) = [i+j  NaN  i  j ...
                            rxnsInfo(b+1, 5)/THA  ...
                            rxnsInfo(b+1, 5)/THA - rxnsInfo(b, 5)/THA];
                    end
                    break
                end
            end
                
        end
    end
end