function [YesNo, nReac, nProd, eqReacProd] ...
    = IsOrNotSelfRep(rxn, MaxL)

%%%%%%%%%%%%%%%%%% Pre-settings %%%%%%%%%%%%%%%%%%%
eqReac = zeros(1, 2);
eqProd = zeros(1, 2);
v = 0;
for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        if rxn(i, j) == 1
            v = v + 1;
            eqReac(v, 1) = i;
            eqReac(v, 2) = j;
            eqProd(v, 1) = i+j;
            eqProd(v, 2) = NaN;
        elseif rxn(i, j) == -1
            v = v + 1;
            eqReac(v, 1) = i+j;
            eqReac(v, 2) = NaN;
            eqProd(v, 1) = i;
            eqProd(v, 2) = j;
        end
    end
end
eqReacProd = cat(2, eqReac, eqProd);

%%%%%%%%%%% Check whether or not self-rep %%%%%%%%%%%%
nReac = [];
nProd = [];
YesNo = 1;
for i = 1 : v
    if isnan(eqReac(i, 2))
        if ~IsaInB(eqReac(i, 1), eqProd, v)
            YesNo = 0;
            break
        end
    else
        if ~IsaInB(eqReac(i, 1), eqProd, v) ...
                && ~IsaInB(eqReac(i, 2), eqProd, v)
            YesNo = 0;
            break
        end
    end
end

%%%%%%%%%%%%%%%%%%%% Decide type %%%%%%%%%%%%%%%%%%%%%
if YesNo
    nReac = zeros(1, MaxL);
    for i = 1 : v
        temp = eqReac(i, 1);
        nReac(temp) = nReac(temp) + 1;
        temp = eqReac(i, 2);
        if ~isnan(temp)
            nReac(temp) = nReac(temp) + 1;
        end
    end
    
    nProd = zeros(1, MaxL);
    for i = 1 : v
        temp = eqProd(i, 1);
        nProd(temp) = nProd(temp) + 1;
        temp = eqProd(i, 2);
        if ~isnan(temp)
            nProd(temp) = nProd(temp) + 1;
        end
    end
end

end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function YesNo = IsaInB(a, eqProd, v)
YesNo = 0;

for i = 1 : v
    if a == eqProd(i, 1)
        YesNo = 1;
        break
    end
    if ~isnan(eqProd(i, 2))
        if a == eqProd(i, 2)
            YesNo = 1;
            break
        end
    end
end

end