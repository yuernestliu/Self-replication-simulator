function [FoodMain, FoodSupp, ExcrPure, ForcSing, ...
    ForcMult, Relevant, NForcMult] = ClassifySet(nReac, nProd)

nReac(nReac == 0) = NaN;
nProd(nProd == 0) = NaN;
nNET = nProd - nReac;

FoodMain = find(~isnan(nReac) &  isnan(nProd));
FoodSupp = find( nNET < 0);
ExcrPure = find( isnan(nReac) & ~isnan(nProd));
ForcSing = find( nNET == 0);
ForcMult = find( nNET > 0);
Relevant = find(~isnan(nReac) | ~isnan(nProd));


NForcMult = sum(nNET(nNET > 0));