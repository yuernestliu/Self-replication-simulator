function DrawReacNet(nOccur, MaxL)

figure
del = 0.05;
l0 = 0.1;
l1 = 4;
colorcomb = [0.0  0.9  0.0]; % green RGB
colorspli = [0.9  0.0  0.0]; % red


hold on
for i = 1 : round(MaxL/2)
    for j = i : MaxL - i
        plot(i, j, 'ko', ...
           'MarkerEdgeColor', 'k', ...
           'MarkerFaceColor', 'k', ...
           'MarkerSize', 10);

        a1 = nOccur(i, j, 1);
        a2 = nOccur(i, j, 2);
        plot3([i, i], [j-del, j-del], [0, a1], ...
            'LineWidth', l0, 'Color', colorcomb);
        plot3([i, i], [j+del, j+del], [0, a2], ...
            'LineWidth', l0, 'Color', colorspli);
        if a1 - a2 > 0
            plot3([i, i], [j-del, j-del], [0, a1-a2], ...
                'LineWidth', l1, 'Color', colorcomb);
        else
            plot3([i, i], [j+del, j+del], [0, a2-a1], ...
                'LineWidth', l1, 'Color', colorspli);
        end
    end
end
for i = 1 : MaxL-1
    quiver(i-MaxL+2, MaxL-1, MaxL-1, -MaxL+1,...
        'Color', 'black', 'AutoScale', 'off');
end

hold off
xticks(1:MaxL)
yticks(1:MaxL)
xlabel('i')
ylabel('j')
set(gca, 'FontSize', 18)
axis([1 MaxL 0 MaxL 0 inf])
axis square
grid on
view(70, 50)