function [rxnsInfo, Numrxns] = ...
    GetrxnsInfoANDOthers(G, mEa, MaxL, beta, RT)

rxnsInfo = zeros(1, 6);
v = 0;

for i = 1 : fix(MaxL/2)
    for j = i : MaxL - i
        temp = G(i+j) - G(i) - G(j);
        if temp >= 0
            temp = temp + mEa(i, j);
        else
            temp = mEa(i, j);
        end
        v = v + 1;
        rxnsInfo(v, 1) = i;
        rxnsInfo(v, 2) = j;
        rxnsInfo(v, 3) = i+j;
        rxnsInfo(v, 4) = 1;
        rxnsInfo(v, 5) = temp;
%         rxnsInfo(v, 6) = alpha * exp( -temp/(RT) );
        rxnsInfo(v, 6) = beta * exp( -temp/RT ); % rate constant

        temp = G(i) + G(j) - G(i+j);
        if temp >= 0
            temp = temp + mEa(i, j);
        else
            temp = mEa(i, j);
        end
        v = v + 1;
        rxnsInfo(v, 1) = i;
        rxnsInfo(v, 2) = j;
        rxnsInfo(v, 3) = i+j;
        rxnsInfo(v, 4) = 2;
        rxnsInfo(v, 5) = temp;
%         rxnsInfo(v, 6) = alpha * exp( -temp/(RT) );
        rxnsInfo(v, 6) = beta * exp( -temp/RT );
    end
end

Numrxns = v;